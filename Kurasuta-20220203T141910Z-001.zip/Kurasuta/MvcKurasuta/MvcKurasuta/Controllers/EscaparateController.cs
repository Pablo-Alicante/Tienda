﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MvcKurasuta.Data;
using MvcKurasuta.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MvcKurasuta.Controllers
{
   
    public class EscaparateController : Controller
    {
        
        private readonly MvcKurasutaContexto _context;
        public EscaparateController(MvcKurasutaContexto context)
        {
            _context = context;
        }
        public IActionResult Index(int? id)
        {
            Escaparate miescaparate = new Escaparate();
            miescaparate.Categorias = _context.Categorias.ToList();
            if (id == null)
            {
                miescaparate.Productos = _context.Productos.ToList();
            }
            else
            {
                miescaparate.Productos = _context.Productos.Where(m => m.CategoriaId == id);
            }
            return View(miescaparate);
        }
    }
}
