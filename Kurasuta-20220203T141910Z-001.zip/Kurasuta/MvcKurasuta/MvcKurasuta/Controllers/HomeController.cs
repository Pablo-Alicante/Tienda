﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MvcKurasuta.Data;
using MvcKurasuta.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MvcKurasuta.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly MvcKurasutaContexto _context;
        public HomeController(ILogger<HomeController> logger, MvcKurasutaContexto context)
        {
            _logger = logger;
            _context = context;
        }
        public IActionResult Index()
        {
            // Busca empleado correspondiente al usuario actual. Si existe
            // va a View y en caso contrario, va a crear el cliente.
            string emailUsuario = User.Identity.Name;
            Cliente cliente = _context.Clientes.Where(e => e.Email == emailUsuario)
            .FirstOrDefault();
            if (User.Identity.IsAuthenticated &&
            User.IsInRole("Usuario") &&
            cliente == null)
            {
                return RedirectToAction("Create", "MisDatos");
            }
            return View();
        }
    }
}
