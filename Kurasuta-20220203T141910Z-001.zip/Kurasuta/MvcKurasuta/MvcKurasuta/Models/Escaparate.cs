﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MvcKurasuta.Models
{
    public class Escaparate
    {
            public IEnumerable<Categoria> Categorias { get; set; }
            public IEnumerable<Producto> Productos { get; set; }
        
    }
}
